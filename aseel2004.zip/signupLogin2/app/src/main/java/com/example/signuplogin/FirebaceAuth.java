package com.example.signuplogin;

import com.google.android.gms.tasks.Task;

public class FirebaceAuth {
    public <TResult> Task<TResult> createUserWithEmailAndPassword(String username, String password) {
    }
}
